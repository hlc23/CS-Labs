# JSON-based CSRF Lab

## Challenge 
Send api request with JSON body from attacker to victim server.
And show the response from victim server.

## 設置
1. 運行 `docker-compose up --build` 啟動服務。
2. Victim API 在 http://localhost:8080
3. Attacker 上傳服務器在 http://localhost:8081
