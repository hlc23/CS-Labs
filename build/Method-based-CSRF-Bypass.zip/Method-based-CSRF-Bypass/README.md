# Method-based CSRF Bypass Lab

## 運行方式
1. 啟動服務：`docker-compose up`
2. 訪問 victim: http://localhost:5000
3. 登入 (user/pass)
4. 訪問 attacker: http://localhost:5001
5. 觀察餘額變化
