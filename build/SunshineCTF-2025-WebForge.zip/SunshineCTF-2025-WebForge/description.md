**NOTE FROM ADMINS**: Use of automated fuzzing tools are allowed for this challenge.
Fuzzing. Not Crawling. All endpoints aside from one are rate limited.

Author: d!!!
